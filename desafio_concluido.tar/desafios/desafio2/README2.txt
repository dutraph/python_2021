
Configure um servidor nginx com dois server names servindo uma rota chamada "desafio".

Em um dos server names, o retorno para um GET deve ser "desafio1".

Para o outro server name, o retorno para um GET deve ser "desafio2".


